CMAKE_MSVCIDE_RUN_PATH
----------------------

.. include:: ENV_VAR.txt

Extra PATH locations for custom commands when using
:generator:`Visual Studio 9 2008` (or above) generators.

The ``CMAKE_MSVCIDE_RUN_PATH`` environment variable sets the default value for
the :variable:`CMAKE_MSVCIDE_RUN_PATH` variable if not already explicitly set.
