.. cmake-module:: ../../Modules/FindXMLRPC.cmake
