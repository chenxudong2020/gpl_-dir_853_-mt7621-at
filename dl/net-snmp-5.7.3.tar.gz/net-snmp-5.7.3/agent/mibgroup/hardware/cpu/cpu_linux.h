config_require(hardware/cpu/cpu)
void init_cpu_linux(void);
