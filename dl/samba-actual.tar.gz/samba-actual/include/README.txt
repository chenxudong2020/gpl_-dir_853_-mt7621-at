this README is needed to ensure that the directory exists in the
source tree. It is needed as a placeholder for the top level build
config.h
