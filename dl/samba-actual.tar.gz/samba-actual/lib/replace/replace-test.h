#ifndef __LIB_REPLACE_REPLACE_TEST_H__
#define __LIB_REPLACE_REPLACE_TEST_H__

bool torture_local_replace(struct torture_context *ctx);
int libreplace_test_strptime(void);
int test_readdir_os2_delete(void);
int getifaddrs_test(void);

#endif /* __LIB_REPLACE_REPLACE_TEST_H__ */

